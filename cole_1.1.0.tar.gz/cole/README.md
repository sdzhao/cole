# cole: COmpound Loss Emporium

Procedures for minimizing various compound loss functions, e.g. squared error loss for the simultaneous estimation of normal means.
