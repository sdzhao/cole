#' @useDynLib cole
#' @importFrom Rcpp evalCpp
#' @importFrom glmnet glmnet cv.glmnet
#' @exportPattern "^[[:alpha:]]+"
#' @import Rcpp RcppArmadillo
NULL
